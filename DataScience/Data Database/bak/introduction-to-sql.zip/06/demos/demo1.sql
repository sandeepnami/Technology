USE contacts;

SELECT p.person_first_name,p.person_last_name
FROM person p
ORDER BY p.person_last_name;
