README.TXT - Quick3270


1) Introduction
2) Contact
3) Price List
4) HLLAPI
5) SNMP
6) Additional options
7) Program history



1) Introduction
   ============
Quick3270 is a powerful, high reliable 3270/5250 terminal emulator for Windows 95/98/NT/2000/XP. Quick3270 is fast, use low memory and includes a large number of advanced features:
- 3270 Connectivity: SNA Server (FMI3270) and TN3270
- 5250 Connectivity: TN5250
- Cut/Copy/Paste Data
- IND$FILE file transfer (Structured Field and Buffered)
- Transfer of list of files
- Graphic support (GDDM,...)
- 3287 Printer emulation (LU1 and LU3)
- OLE Automation Server
- Macro language
- HLLAPI support
- Large number of host code pages
- English, French, German and Portuguese user interfaces
- English, French and German help files
- SNMP support
- and many more...
Site license and the complete C/C++ source code are available.

Please contact me if you want to report bugs, grammar mistakes, or
give your opinion about the program, or any comments etc...



2) Contact
   =======
DN-Computing
7, rue du Foss�
67150 Erstein - France
Fax: +33 (0)3 88 98 21 20

e-mail : info@dn-computing.com
WWW    : http://www.dn-computing.com



3) Prices
   ======
(applicable until December 2002)
  Single User license             $30 US  or     30 euros
  100 user license             $2,000 US  or  2,000 euros
  Site license                 $3,500 US  or  3,500 euros
  Site license + source code  $10,000 US  or 10,000 euros                   


The pricing set applies to all customers. Payment for all international
sales are required in US Dollars or Euro and should be made in cash,
cheque or via wire transfer. French customers must add 19,6% VAT.

On-line order using the secured RegNow! server: 
- Single User license: https://www.regnow.com/softsell/nph-softsell.cgi?item=1947-1
- Site license: https://www.regnow.com/softsell/nph-softsell.cgi?item=1947-2


4) HLLAPI
   ======
Quick3270 High Level Language API provides compatibility with IBM's High
Level Language API (High Level Language Application Program Interface).
Quick3270 supports currently 29 of 44 standard High Level Language API functions.
The HLLAPI DLL file name is QHLLAPI.DLL. This DLL is designed for
Windows 32 bits application and works only for 3270 emulation yet.

Summary of available HLLAPI functions:
 1 - CONNECTPS                       20 - QUERYSYSTEM
 2 - DISCONNECTPS                    21 - RESETSYSTEM
 3 - SENDKEY                         22 - QUERYSESSIONSTATUS
 4 - WAIT                            23 - STARTHOSTNOTIFICATION
 5 - COPYPS                          24 - QUERYHOSTUPDATE
 6 - SEARCHPS                        25 - STOPHOSTNOTIFICATION
 7 - QUERYCURSORLOC                  30 - SEARCHFIELD
 8 - COPYPSTOSTR                     31 - FINDFIELDPOSITION
 9 - SETSESSIONPARAMETERS            32 - FINDFIELDLENGTH
10 - QUERYSESSIONS                   33 - COPYSTRINGTOFIELD
11 - RESERVE                         34 - COPYFIELDTOSTRING
12 - RELEASE                         40 - SETCURSOR
13 - COPYOIA                         90 - SENDFILE                
14 - QUERYFIELDATTRIBUTE             91 - RECEIVEFILE 
15 - COPYSTRTOPS                     99 - CONVERT
18 - PAUSE                           

 
List of supported options you can set with SETSESSIONPARAMETERS:
STRLEN/STREOT, EOT=c, ESC=c, AUTORESET/NORESET, TWAIT/LWAIT/NWAIT,
NOATTRB/ATTRB, EAB/NOEAB, XLATE/NOXLATE, DISPLAY/NODISPLAY,STRLEN/STREOT, EOT=c,
SRCHALL/SRCHFROM, SRCHFRWD/SRCHBKWD, NOCFGSIZE/CFGSIZE, OLDOIA/NEWOIA,
FPAUSE/IPAUSE 

How to use the QHLLAPI.DLL from a C file
----
HINSTANCE hHllapi_DLL;
WORD wFunction;
WORD wRetCode;

hHllapi_DLL = LoadLibrary("C:\\Program Files\\Quick3270\\QHLLAPI.dll");
hllapi = (LPFNDLL_hllapi) GetProcAddress(hHllapi_DLL, "hllapi");

wFunction = 21;   // Reset
hllapi(&wFunction, NULL, NULL, &wRetCode);
switch (wRetCode) {
   case RC_INVALID_PS:
      // 1  HLLAPI not Loaded
      break;
   case RC_SYSTEM_ERROR:  
      break;
}

...

----


5) SNMP
   ====
To install SNMP for Quick3270:
- A SNMP agent must already be installed on the PC
- Quick3270: go to Settings->Terminal->Registry Tab: push the Write button
(this will update the registry with the Quick3270 extension agent, coded in QCore.dll)
- NT/2000/XP: stop and restart the SNMP agent service (Win NT or Win2000)

MIB for DN-Computing is 8624.
Currently you can collect the response time with SNMP.
(sample: snmputil getnext localhost public .1.3.6.1.4.1.8624.2.5.0)
New/Specific SNMP functions can be added on request.



6) Additional options
   ==================
Options you can add to the configuration file or registry
to hide some menu options. This options will even be removed
from the toolbar.

[Menu]
HideMenuBar=True
HideNew=True
HideOpen=True
HideOpenSame=True
HideOpenNew=True
HideSave=True
HideSaveAs=True
HideSaveAsDefault=True
HideOpenLayout=True
HideSaveLayout=True

HideSessionCfg=True;
HideFileTransfer=True;
HideMacroEdit=True;
HideMacroRecord=True;
HideKeybordMap=True;


Alarm option: Sound alarm if a given character is at the given
screen location.
(sample: Sound alarm every second if the character "U" is at location 1,1)
[Alarm] 
AlarmOn=True
Row=1
Line=1
Timer=1000
Token=U



7) Program history
   ===============
June 02 - v3.30
    - Added: 3812 Printer emulation (TN5250)
    - Added: Device name negociation (TN5250)
    - Added: Image support for graphic emulation
    - New: Quick3270 Thai Edition available from Fujitsu Thailand

Jan 02 - v3.22
    - Added: Customizable window title
    - Added: Auto-reconnect option (Telnet)
    - Added: "Run the same" and "Run other..." menu option
    - Added: Option to to popup keypad on right mouse clic  
    - Fixed: "Destructive Backspace" option don't work in 5250 mode
    - Fixed: Some function key bug on 5250 emulation

Nov 01 - v3.21
    - Added: Left Ctrl key can be mapped
    - Improved Bitmap font resizing

Nov 01 - v3.20
    - Added: HLLAPI interface
    - Added: SNMP support
    - Added: Customizable toolbar
    - Added: Message line for 5250 emulation
    - Added: Transfer list of files
    - Added: Auto-start macro
    - Added: Record macro option
    - Added: Graphic screens are resizable

July 01 - v3.17
    - Added: Thai Host Code Page
    - Added: Lines per Inch option for 3287 emulation
    - Improved support for graphic emulation (3179G)
    - Fixed: TN5250 negotiation problem on some server
    - Fixed: Bug when several sessions are started with the layout file
    - Fixed: Several bugs with the macro language
    - Fixed: A Bracket error with SNA Server connection (FMI)

Feb 01 - v3.10
    - Added: Script language
    - Added: Support of layout file (to save several sessions, display and printer, in one file) 
    - Added: New keys: Next Word, Previous Word
    - Added: COM IPersistFile support
    - Added: LU name is now displayed on the status bar (3270)
    - Added: Settings can now be save in the registry 
    - Fixed: Several file transfer bugs with IND$FILE in CUT mode
    - Fixed: An Automation deadlock is removed


Oct 00 - v3.07
    - Added: Printer page settings are now backed up in the configuration files (Quick3270 and Quick3287)
    - Fixed: Quick3287 printing problem due to the new "ByPass GDI" code (doesn't print if "ByPass GDI" option is not selected)


Oct 00 - v3.06
    - Added: Purchase online menu option
    - Added: Code pages for Euro currency symbol
    - Added: Quick3287 LU1 transparency support


Oct 00 - v3.05
    - Added: Recent file list
    - Added: Quick3270 configuration files area now associated with the application
    - Added: Menu bar can now be hidden
    - Changed: User settings are now stored under the HKEY_CURRENT_USER key
    - Fixed: Input focus problem after a click on a keypad button
    - Fixed: The Keypad can no more be maximized


Sept 00 - v3.04
    - Added: Row oriented paste data option (Scott Burch)
    - Added: Telnet Keep-Alive option (Richard C. Luna)
    - Fixed: OLE Automation incompatibility with new protection system (Juan Carlos Daza)
    - Fixed: "Open session" and "Open Session new" incompatibility with new protection system


Sept 00 - v3.03
    - Added: End Of Field key (Ctrl-End)
    - Fixed: File transfer, wrong conversion of the "Y" character 
             when receiving text files (Tom Hansen)
    - Fixed: Blinking attribute was ignored under some conditions
    - Fixed: Graphic draw line was one pixel too short


August 00 - v3.02
    - Fixed: Connection problem on some TN3270E server
    - Fixed: Keypad window may have a bad size


July 00 - v3.00
    - Added: 5250 terminal emulation
    - Added: Context help
    - Added: Lightpen support
    - Changed: New software protection system


May 00 - v2.69
    - Fixed: Printer Emulator unable to connect in TN3270E mode


May 00 - v2.68
    - Added: Append option when sending file to host
    - Added: Print timestamp header on print screen
    - Added: Possibility to start the program from a WEB page URL like tn3270://hostname [port]
    - Fixed: Read Buffer bug - program may crash under some circumstances
    - Fixed: Display bug on progress bar for large file transfer  
    - Fixed: File transfer dialog box update bug.
             Settings were not properly updated when a file transfer scheme file was selected


February 00 - v2.60
    - Added: Host graphic support (GDDM,...)
    - Added: 3287 host print
    - Added: Improved NVT/ANSI emulation
    - Added: OLE functions for IND$FILE file transfer
    - Added: DUP and Fieldmark keys


October 99 - v2.50
    - Added: Code Page support for File transfer
    - Added: Page setup and printer font selection
    - Added: French and German user interface and help file
    - Shortcut for the cent character (Alt+c)


September 99 - v2.27
    - Fixed: Program could crash when using IND$FILE file transfer with TN3270 connectivity


September 99 - v2.26
    - Fixed: Bad ANSI to EBCDIC translation for some language specific characters


June 99 - v2.25
    - Fixed: Accept now uppercase characters on Numeric Fields
    - Fixed: Correct the GetString Automation Error when a negative length is given
    - Automation: The software starts in invisible mode now


June 99 - v2.24
    - Fixed: Program crash when rigth control key is pressed


May 99 - v2.23
    - Added: OLE MoveTo, MoveRelative, Row and Col function calls are buffered
             if type ahead is enable to avoid synchronization problems
    - Fixed: Attn key now flushes the type ahead buffer
    - Fixed: Unable to disable the type ahead buffer
             

May 99 - v2.22
    - Added: Display an error message if the SNA Server DLL is not found
    - Fixed: Display bug with NVT data's (TN3270E connection)
    - Fixed: Type ahead bug with TN3270 connection
    - Fixed: Focus problem on the select font Dialog box
    - Fixed: Bad Cursor placement for BackTab and Home Keystrokes
    - Fixed: Pf19 and Pf20 were inverted
    - Fixed: Printer LUs are listed in the screen Session Settings Dialog box
    - Fixed: File transfer bug with TN3270 connection
    - Fixed: Bug on Visible OLE property


April 99 - v2.21
    - Faster screen update


April 99 - v2.20
    - Added: Customizable colors and keyboard remapping
    - Added: Type ahead buffer
    - Added: 3270 function Keys (Fast Left, Fast right, Erase Input)
    - Fixed: Connection problem with some TN3270E Server


March 99 - v2.10
    - Added: Support for IND$FILE file transfer (CMS, TSO and CICS)
    - Improved 3270 data parser
    - Added: Install/Uninstall program
    - Added: 3270 function keys (Attention and SysReq)


January 99 - v2.02
    - Added: TN3270E support
    - Fixed: Bug with SNA Server connection under Windows NT


December 98 - v2.01
    - Added: Support of blinking attribute
    - Fixed: Display bug on color attributes
    - Fixed: Bug on OLE Wait... functions


December 98 - v2.0
    - Added: TN3270 connectivity
    - Added: OLE Automation Server feature
    - Added: Trace file (read and write)
    - Added: Toolbar


April 98 - v1.0
    - First release of Quick3270.
    - Includes the basic features of a 3270 emulator.
    - Connects to MS SNA Server using the FMI API.
    - Support most of the extended attributes .
    - Partial support of Graphic Escape characters
    - Support of Cut/Copy/Paste data
